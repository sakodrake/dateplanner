import React from 'react';
import { Calendar, Clock, DollarSign, MapPin, Sun } from 'lucide-react';
import type { DateSuggestion } from '../types/date';

interface DateCardProps {
  suggestion: DateSuggestion;
}

export function DateCard({ suggestion }: DateCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
      <h3 className="text-xl font-semibold mb-3 text-gray-800">{suggestion.title}</h3>
      <p className="text-gray-600 mb-4">{suggestion.description}</p>
      
      <div className="space-y-2">
        <div className="flex items-center text-gray-600">
          <DollarSign className="w-5 h-5 mr-2" />
          <span>{suggestion.estimatedCost}</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Clock className="w-5 h-5 mr-2" />
          <span>{suggestion.timeOfDay}</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Sun className="w-5 h-5 mr-2" />
          <span>{suggestion.weatherSuitability.join(', ')}</span>
        </div>
        
        {suggestion.location && (
          <div className="flex items-center text-gray-600">
            <MapPin className="w-5 h-5 mr-2" />
            <span>{suggestion.location}</span>
          </div>
        )}
      </div>
      
      <div className="mt-4">
        <span className="inline-block bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
          {suggestion.category}
        </span>
      </div>
    </div>
  );
}