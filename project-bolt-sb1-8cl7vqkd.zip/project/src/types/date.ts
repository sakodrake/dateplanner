export interface DateSuggestion {
  title: string;
  description: string;
  category: string;
  estimatedCost: string;
  timeOfDay: string;
  weatherSuitability: string[];
  location?: string;
}

export interface LocationInfo {
  city: string;
  country: string;
}