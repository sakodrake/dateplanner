import React, { useState } from 'react';
import { Heart, Loader2 } from 'lucide-react';
import { DateCard } from './components/DateCard';
import { LocationInput } from './components/LocationInput';
import type { DateSuggestion } from './types/date';

function App() {
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [dateSuggestions, setDateSuggestions] = useState<DateSuggestion[]>([]);

  const generateDateIdeas = async () => {
    if (!location.trim()) return;
    
    setLoading(true);
    // In a real application, you would make an API call to your backend
    // which would then use OpenAI's API to generate date suggestions
    // For demo purposes, we'll simulate a delay and return mock data
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockSuggestions: DateSuggestion[] = [
      {
        title: "Sunset Picnic at Central Park",
        description: "Pack a romantic basket with local delicacies and enjoy a peaceful evening watching the sunset together.",
        category: "Outdoor",
        estimatedCost: "$$",
        timeOfDay: "Evening",
        weatherSuitability: ["Sunny", "Mild"],
        location: "Central Park, New York"
      },
      {
        title: "Cooking Class Adventure",
        description: "Learn to make authentic Italian pasta together at a local culinary school.",
        category: "Indoor Activity",
        estimatedCost: "$$$",
        timeOfDay: "Afternoon",
        weatherSuitability: ["Any"],
        location: "Downtown Culinary Institute"
      },
      {
        title: "Rooftop Cinema Experience",
        description: "Enjoy a classic romantic movie under the stars with city views and gourmet snacks.",
        category: "Entertainment",
        estimatedCost: "$$",
        timeOfDay: "Night",
        weatherSuitability: ["Clear", "Mild"],
        location: "Rooftop Cinema Club"
      }
    ];
    
    setDateSuggestions(mockSuggestions);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-12 h-12 text-red-500 mr-2" />
            <h1 className="text-4xl font-bold text-gray-800">DatePlanner AI</h1>
          </div>
          <p className="text-xl text-gray-600 mb-8">
            Let AI help you plan the perfect date based on your location
          </p>
          
          <div className="flex justify-center mb-12">
            <LocationInput
              location={location}
              setLocation={setLocation}
              onSubmit={generateDateIdeas}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            <span className="ml-2 text-gray-600">Generating perfect date ideas...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dateSuggestions.map((suggestion, index) => (
              <DateCard key={index} suggestion={suggestion} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;